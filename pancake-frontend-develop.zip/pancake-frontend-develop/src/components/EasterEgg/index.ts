export { default } from './EasterEgg'
